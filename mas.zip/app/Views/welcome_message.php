<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ahlan wa sahlan</title>
    <meta name="description" content="The small framework with powerful features">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="/favicon.ico">

   
</head>
<body>


<script {csp-script-nonce}>
    document.addEventListener('DOMContentLoaded', () => {
        console.log('jhkjh khkjhkjhk');
        window.open('<?= base_url()?>login', '_self')
        
      });
</script>

<!-- -->

</body>
</html>
